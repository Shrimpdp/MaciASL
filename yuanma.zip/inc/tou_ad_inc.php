<?php
define('tou_ad1', '');
define('tou_ad1s', '');
define('tou_ad2', '');
define('tou_ad2s', '');
define('tou_ad3', '');
define('tou_ad3s', '');
define('tou_ad4', '');
define('tou_ad4s', '');
define('tou_ad5', '');
define('tou_ad5s', '');
?>