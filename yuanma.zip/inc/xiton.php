<?php
//系统设置
define('XXXXXXXXXX1', '588福利电影区');
define('XXXXXXXXXX2', '588福利电影区');
define('XXXXXXXXXX3', '提供学生妹、熟女少妇、人妻、空姐模特、乱伦、自慰群交、野战车震、无码、强奸、巨乳、乱伦、制服、人妻、调教、出轨、中文字幕、av、国产三级片在线观看视频');
define('XXXXXXXXXX4', '提供学生妹、熟女少妇、人妻、空姐模特、乱伦、自慰群交、野战车震、无码、强奸、巨乳、乱伦、制服、人妻、调教、出轨、中文字幕、av、国产三级片在线观看视频');
define('XXXXXXXXXX5', 'moban8');
define('XXXXXXXXXX6', 'zeist1111@gmail.com');
define('XXXXXXXXXX8', '/image/logo.jpg');
?>