<?php
//友情链接设置
define('XXXXXXXXXX13', '');
?>