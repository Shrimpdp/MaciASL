<?php
//后台密码
define('USERNAME', 'admin');
define('PASSWORD', 'php85');
define('IPPASS', '');
?>