<div class="xx15 pt10">
	<div class="hd-2">系统设置</div>
	<div class="bd-2">
		<a class="btn btn-block bg-black" href="index.php">后台首页</a>
		<a class="btn btn-block bg-black" href="system.php">基本设置</a>
		<a class="btn btn-block bg-black" href="ad.php">广告管理</a>
		<a class="btn btn-block bg-black" href="nav.php">友链管理</a>
		<a class="btn btn-block bg-black" href="ccg.php">安全管理</a>


	</div>




</div>
