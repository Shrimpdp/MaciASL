﻿
<?php

// 定义应用目录
include('./app/index.php');
?>
